#!/bin/bash
echo

#which python
#python --version
#echo

#which pip
#pip --version
#echo

site='_ike4'
#site='_mums'

venvdir='ve_analytics_202001'

req='req_ve_analytics_202001.txt'

echo '  req: ' $req
echo '  bin: ' $bin
echo '  src: ' $src
echo

if [ $site = '_ike4' ]; then
	workbench='/c/dev/workbench'
	wheelhouse='/c/dev/workbench/wheelhouse_202001'
	#log="/c/dev/workbench/log_updtpkg$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
	#exec > >(tee ${log}) 2>&1
elif [ $site = '_mums' ]; then
	workbench='/d/workbench'
	wheelhouse='/m/eq.trd/Development/wheelhouse_202001'
	#log="/d/workbench/log_updtpkg$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
	#exec > >(tee ${log}) 2>&1
else
	echo 'error site'
fi

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - START \\n"

cd $workbench/$venvdir

source Scripts/activate
echo 'activated: '$venvdir
echo

which python
python --version
echo

which pip
pip --version
echo

#Scripts/python get-pip.py --upgrade pip --no-cache-dir 
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pip==20.1
echo

#Scripts/python get-pip.py --upgrade wheel --no-cache-dir 
Scripts/python get-pip.py --no-index --no-setuptools --find-links=$wheelhouse wheel==0.34.2
echo

#Scripts/python get-pip.py --upgrade setuptools --no-cache-dir 
Scripts/python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==46.2
echo

pip freeze > $workbench/'_'$venvdir$site'_piplist.txt'
pip uninstall -y -r $workbench/'_'$venvdir$site'_piplist.txt'
echo

#Scripts/python get-pip.py --upgrade pipdeptree --no-cache-dir 
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pipdeptree==0.13.2
echo

pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse -r $workbench/$req
echo

#jupyter notebook --generate-config
#echo

jupyter serverextension enable --py jupyterlab --sys-prefix
echo

jupyter nbextensions_configurator enable --user
echo

jupyter contrib nbextension install --user
echo

jupyter nbextension enable autosavetime/main
jupyter nbextension enable codefolding/main
jupyter nbextension enable collapsible_headings/main
jupyter nbextension enable equation-numbering/main
jupyter nbextension enable execute_time/ExecuteTime
jupyter nbextension enable toc2/main
echo

jupyter nbextension enable --py widgetsnbextension --sys-prefix
echo

jupyter nbextension enable --py bqplot --sys-prefix
#jupyter nbextension disable --py bqplot
echo

python -m pipdeptree --warn silence --local-only --freeze --all > $workbench/'_'$venvdir$site'_package_dep.txt'
python -m pipdeptree --warn silence --local-only --freeze --all --reverse > $workbench/'_'$venvdir$site'_package_dep_rev.txt'

pip freeze > $workbench/'_'$venvdir$site'_package_freeze.txt'
echo

pip list > $workbench/'_'$venvdir$site'_package_list.txt'
echo

if [ $site = '_ike4' ]; then
	pip list -o > $workbench/$site'_package_update.txt'
	pip list -o
	echo
elif [ $site = '_mums' ]; then
	echo 'skipped pip list -o'
else
	echo 'error site'
fi

cd $workbench/$venvdir/Scripts
deactivate
echo 'deactivated: '$venvdir
echo
cd $workbench

#python --version
#which python
#echo

echo "completed"
echo

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - END \\n"


