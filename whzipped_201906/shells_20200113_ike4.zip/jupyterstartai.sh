
#!/bin/bash
echo
echo 'jupyterstartai.sh started'
echo

which python
python --version
echo


site='_ike4'
#site='_mums'

venvdir='ve_ai'	
#venvdir='ve_jupyter_201906'	
#venvdir='ve_test'	

workbench='/c/dev/workbench'
log="/c/dev/workbench/log_tensorboard$site"_"`date '+%Y%m%d_%H%M%S'`.txt"

#workbench='/d/workbench'
#log="/d/workbench/log_tensorboard$site"_"`date '+%Y%m%d_%H%M%S'`.txt"

#tblog='/c/dev/workbench/notebook/Python/src/DeepLearning'
#tblog='/d/workbench/notebook/Python/src/DeepLearning'
#exec > >(tee ${log}) 2>&1

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - START \\n"

cd $workbench/$venvdir

source Scripts/activate
echo 'activate: '$venvdir
echo

which python
python --version
echo

which jupyter
jupyter --version
echo

echo 'TensorBoard started '$tblog/logs 
echo

#tensorboard --logdir=./logs
tensorboard --logdir=$tblog/logs

echo 'jupyterstartai.sh ended'
echo



