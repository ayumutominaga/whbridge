#!/bin/bash
echo

site='_ike4'
#site='_mums'

if [ $site = '_ike4' ]; then
	echo 'skipped proxy'
elif [ $site = '_mums' ]; then
	set https_proxy=http://214671:Oxygen-8@proxyc.d0001.local:8080
	set http_proxy=http://214671:Oxygen-8@proxyc.d0001.local:8080
#	pip list -o
else
	echo 'canceled proxy'
fi

py --list-paths
echo

#which python
#echo

#py -3.6 --version
#python --version
#echo

echo $PYTHON3_HOME
echo

#venvdir=''   # for original Python
#venvdir='ve_test_201906'
venvdir='ve_ai_201906'
#venvdir='ve_analytics_201906'
#venvdir='ve_jupyter_201906'

req=''
add='req_update_add_201906.txt'
bin='req_update_bdist_201906.txt'
src='req_update_sdist_201906.txt'

echo '  req: ' $req
echo '  add: ' $add
echo '  bin: ' $bin
echo '  src: ' $src
echo

if [ $site = '_ike4' ]; then
	workbench='/c/dev/workbench'
	wheelhouse='/c/dev/workbench/wheelhouse_201906'
	wheel_maker='/c/dev/workbench/wheel_maker'
	#log="/c/dev/workbench/log_updtpkg$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
	#exec > >(tee ${log}) 2>&1
elif [ $site = '_mums' ]; then
	workbench='/d/workbench'
	wheelhouse='/m/eq.trd/Development/wheelhouse_201906'
	wheel_maker='/m/eq.trd/Development/wheel_maker'
	#log="/d/workbench/log_updtpkg$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
	#exec > >(tee ${log}) 2>&1
else
	echo 'error site'
fi

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - START \\n"

cd $workbench/$venvdir
source Scripts/activate
echo 'activated: '$venvdir
echo

which python
echo

py -3.6 --version
python --version
echo

which pip
echo

py -3.6 -m pip --version
echo

#python get-pip.py --upgrade pip
#python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pip==20.1
#echo

#python get-pip.py --upgrade wheel
#python get-pip.py --no-index --no-setuptools --find-links=$wheelhouse wheel==0.34.2
#echo

#python get-pip.py --upgrade setuptools
#python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==46.2
#echo

#pip freeze > $workbench/$site'_piplist.txt'
#pip uninstall -y -r $workbench/$site'_piplist.txt'
#echo

#pip uninstall -y tensorboard
#pip uninstall -y prompt_toolkit
#pip uninstall -y jupyterlab
#pip uninstall -y jupyter-console
#pip uninstall -y PyQt5
#pip uninstall -y PyQtWebEngine
#pip uninstall -y gast
#pip uninstall -y jedi 
#pip uninstall -y wrapt
#pip uninstall -y jupyterlab-server

#python get-pip.py --upgrade pipdeptree
#python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pipdeptree==0.13.2
#echo

### python setup.py sdist --format=gztar,zip
### python setup.py bdist_wheel

#pip uninstall -y blpapi 
#python -m pip install --index-url=https://bloomberg.bintray.com/pip/simple blpapi
#pip wheel --wheel-dir $wheelhouse --index-url=https://bloomberg.bintray.com/pip/simple blpapi==3.9.2
#pip wheel --wheel-dir $wheelhouse --index-url=https://bloomberg.bintray.com/pip/simple blpapi==3.12.2
#pip wheel --wheel-dir $wheelhouse --index-url=https://bloomberg.bintray.com/pip/simple blpapi==3.13.1
#pip wheel --wheel-dir $wheelhouse --index-url=https://bloomberg.bintray.com/pip/simple blpapi==3.14.0
#pip wheel --wheel-dir $wheelhouse blpapi==3.9.2 
#pip wheel --wheel-dir $wheelhouse blpapi==3.12.2 
#pip wheel --wheel-dir $wheelhouse blpapi==3.13.1 
#pip wheel --wheel-dir $wheelhouse blpapi==3.14.0 
#pip install $wheelhouse/blpapi-3.9.2.tar.gz
#pip install $wheelhouse/blpapi-3.12.2.tar.gz
#pip install $wheelhouse/blpapi-3.13.1.tar.gz
#pip install $wheelhouse/blpapi-3.14.0.tar.gz
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse blpapi==3.9.2
####pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse blpapi==3.12.2
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse blpapi==3.13.1
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse blpapi==3.14.0
#echo

#pip wheel --wheel-dir $wheelhouse jupyterlab-server==0.3.3 
#pip wheel --wheel-dir $wheelhouse pixiedust_rosie==0.4 
#pip wheel --wheel-dir $wheelhouse rosie==1.1.3 
#pip wheel --wheel-dir $wheelhouse pixiedust_rosie 
#echo

echo 'src'
#pip wheel --wheel-dir $wheelhouse -r $workbench/$src 
py -3.6 -m pip wheel --wheel-dir $wheelhouse -r $workbench/$src 
echo

echo 'bin'
#pip wheel --wheel-dir $wheelhouse -r $workbench/$bin
py -3.6 -m pip wheel --wheel-dir $wheelhouse -r $workbench/$bin
echo

#wheel convert --dest-dir $wheel_maker $wheel_maker/dist/blpapi-3.13.1-py3.6-win-amd64.egg
echo

echo 'add'
#pip --no-cache-dir install --ignore-installed --no-index --upgrade --find-links=$wheelhouse -r $workbench/$add
py -3.6 -m pip --no-cache-dir install --ignore-installed --no-index --upgrade --find-links=$wheelhouse -r $workbench/$add
echo


#pip uninstall -y jupyterlab 
#echo

#pip uninstall -y gast 
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse gast==0.2.2
#echo 'for tensorflow==2.0'

#pip uninstall -y pdblp 
##pip install $wheelhouse/pdblp-0.1.8.tar.gz
##pip install $wheelhouse/pdblp==0.1.8							
##pip wheel -w $wheelhouse pdblp==0.1.8
##pip install --no-index --upgrade -f $wheelhouse pdblp==0.1.8	
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse pdblp==0.1.8
#echo

#jupyter notebook --generate-config

#jupyter contrib nbextension install --user
#echo

#jupyter nbextensions_configurator enable --user
#echo

#jupyter nbextension enable codefolding/main
#echo

#jupyter contrib nbextensions migrate
#echo

### jupyter nbextension enable --py widgetsnbextension --sys-prefix
#echo

#jupyter nbextension enable --py bqplot --sys-prefix
#echo

#jupyter nbextension disable --py bqplot
#echo

#jupyter serverextension enable --py jupyterlab --sys-prefix
#echo

python -m pipdeptree --warn silence --local-only --freeze --all > $workbench/$site'_package_dep.txt'
python -m pipdeptree --warn silence --local-only --freeze --all --reverse > $workbench/$site'_package_dep_rev.txt'

pip freeze > $workbench/$site'_package_freeze.txt'
echo

pip list > $workbench/$site'_package_list.txt'
echo

if [ $site = '_ike4' ]; then
	pip list -o > $workbench/$site'_package_update.txt'
	pip list -o
	echo
	pip check
	pip check > $workbench/$site'_package_dependency.txt'
	echo
elif [ $site = '_mums' ]; then
	echo 'skipped pip list -o'
	echo 'skipped pip check'
	echo
else
	echo 'error site'
	echo
fi

cd $workbench/$venvdir/Scripts
deactivate
echo 'deactivated: '$venvdir
echo
cd $workbench

#python --version
#py -3.6 --version
#which python
#echo

echo "completed"
echo

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - END \\n"


