#!/bin/bash
echo

which python
python --version
echo

which pip
pip --version
echo

site='_ike4'
#site='_mums'

venvdir='ve_test'

req='req_ve_test.txt'

echo '  req: ' $req
echo '  bin: ' $bin
echo '  src: ' $src
echo

workbench='/c/dev/workbench'
wheelhouse='/c/dev/workbench/wheelhouse_201906'

#workbench='/d/workbench'
#wheelhouse='/m/eq.trd/Development/wheelhouse_201906'

#log="/c/dev/workbench/log_instpkg_$venvdir$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
#log="/d/workbench/log_instpkg_$venvdir$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
#exec > >(tee ${log}) 2>&1

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - START \\n"

cd $workbench/$venvdir

source Scripts/activate
echo 'activated: '$venvdir
echo

which python
python --version
echo

which pip
pip --version
echo

#Scripts/python get-pip.py --upgrade pip
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pip==19.3.1
echo

#Scripts/python get-pip.py --upgrade wheel
Scripts/python get-pip.py --no-index --no-setuptools --find-links=$wheelhouse wheel==0.33.6
echo

#Scripts/python get-pip.py --upgrade setuptools
# for tensorflow==1.9.0
Scripts/python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==42.0.1
echo

pip freeze > $workbench/'_'$venvdir$site'_piplist.txt'
pip uninstall -y -r $workbench/'_'$venvdir$site'_piplist.txt'
echo

#Scripts/python get-pip.py --upgrade pipdeptree
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pipdeptree==0.13.2
echo

pwd
echo

### python setup.py sdist --format=gztar,zip
### python setup.py bdist_wheel

#pip wheel -w $wheelhouse -r $workbench/$src --no-cache-dir 
echo

#pip wheel -w $wheelhouse -r $workbench/$bin --no-cache-dir 
echo

#pip uninstall -y -r $workbench/$req
#pip install --upgrade -r $workbench/$req
#pip install --use-wheel --no-index --upgrade -f $wheelhouse -r $workbench/$req
#pip install --no-index --upgrade --find-links=$wheelhouse -r $workbench/$req
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse -r $workbench/$req
#pip --no-cache-dir install --ignore-installed --no-index --upgrade -f $wheelhouse -r $workbench/$req
#pip uninstall -y -r $workbench/$req
#pip --no-cache-dir install --force-reinstall --ignore-installed --no-index --upgrade -f $wheelhouse -r $workbench/$req
#pip --no-cache-dir install --ignore-installed --no-index --upgrade -f $wheelhouse -r $workbench/$req
pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse -r $workbench/$req
echo

#pip install $wheelhouse/pipdeptree-0.13.1.tar.gz
#pip install $wheelhouse/pipdeptree==0.13.1							
#pip wheel -w $wheelhouse pipdeptree==0.13.1
#pip install --no-index --upgrade --find-links=$wheelhouse pipdeptree==0.13.1	
#echo

#pip uninstall -y blpapi 
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse blpapi==3.9.2
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse blpapi==3.13.0
#echo

#pip uninstall -y pdblp 
##pip install $wheelhouse/pdblp-0.1.8.tar.gz
##pip install $wheelhouse/pdblp==0.1.8							
##pip wheel -w $wheelhouse pdblp==0.1.8
##pip install --no-index --upgrade -f $wheelhouse pdblp==0.1.8	
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse pdblp==0.1.8
#echo

#pip install --upgrade jupyter_contrib_nbextensions
#pip install --upgrade https://github.com/ipython-contrib/jupyter_contrib_nbextensions/tarball/master
#echo

#jupyter notebook --generate-config
#echo

jupyter serverextension enable --py jupyterlab --sys-prefix
echo

jupyter nbextensions_configurator enable --user
echo

jupyter contrib nbextension install --user
echo

jupyter nbextension enable autosavetime/main
jupyter nbextension enable codefolding/main
jupyter nbextension enable collapsible_headings/main
jupyter nbextension enable equation-numbering/main
jupyter nbextension enable execute_time/ExecuteTime
jupyter nbextension enable toc2/main
echo

#jupyter nbextension enable --py widgetsnbextension --sys-prefix
#echo

jupyter nbextension enable --py bqplot --sys-prefix
#jupyter nbextension disable --py bqplot
echo

python -m pipdeptree --warn silence --local-only --freeze --all > $workbench/'_'$venvdir$site'_package_dep.txt'
python -m pipdeptree --warn silence --local-only --freeze --all --reverse > $workbench/'_'$venvdir$site'_package_dep_rev.txt'

pip freeze > $workbench/'_'$venvdir$site'_package_freeze.txt'
echo

pip list > $workbench/'_'$venvdir$site'_package_list.txt'
echo

pip list -o > $workbench/'_'$venvdir$site'_package_update.txt'
pip list -o
echo

cd $workbench/$venvdir/Scripts
deactivate
echo 'deactivated: '$venvdir
echo
cd $workbench

python --version
which python
echo

echo "completed"
echo

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - END \\n"


