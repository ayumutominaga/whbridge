#!/bin/bash
echo

py --list-paths
echo

#which python
#python --version
#echo

#which pip
#pip --version
#echo

site='_ike4'
#site='_mums'

venvdir='ve_test_201906'
#venvdir='ve_ai_201906'
#venvdir='ve_analytics_201906'
#venvdir='ve_jupyter_201906'

if [ $site = '_ike4' ]; then
	workbench='/c/dev/workbench'
	wheelhouse='/c/dev/workbench/wheelhouse_201906'
elif [ $site = '_mums' ]; then
	workbench='/d/workbench'
	wheelhouse='/m/eq.trd/Development/wheelhouse_201906'
else
	echo 'error site'
fi

cd $workbench
pwd
echo

if [ -e $venvdir ]; then
	rm -rf $venvdir
	py -3.6 -m venv $venvdir --clear
	#python -m venv $venvdir --clear
	#python -m venv $venvdir --update
	echo $venvdir ' exist'
else
	mkdir $venvdir
	py -3.6 -m venv $venvdir
	#python -m venv $venvdir
	echo $venvdir ' not exist'
fi

cp $workbench/get-pip.py $workbench/$venvdir/get-pip.py


if [ $site = '_mums' ]; then
	if [ $venvdir = 've_test_201906' ]; then
		cp $workbench/activate_test_201906 $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_test_201906'
	elif [ $venvdir = 've_ai_201906' ]; then
		cp $workbench/activate_ai_201906 $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_ai_201906'
	elif [ $venvdir = 've_analytics_201906' ]; then
		cp $workbench/activate_analytics_201906 $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_analytics_201906'
	elif [ $venvdir = 've_jupyter_201906' ]; then
		cp $workbench/activate_jupyter_201906 $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_jupyter_201906'
	else
		echo $venvdir ' process else'
		:
	fi	
else
	echo $site ' copy activate skipped'
fi

cd $venvdir
pwd
echo

source Scripts/activate

which python
echo

py -3.6 --version
python --version
echo

which pip
echo

py -3.6 -m pip --version
echo

#Scripts/python get-pip.py --upgrade pip
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pip==20.0.2
echo

#Scripts/python get-pip.py --upgrade wheel
Scripts/python get-pip.py --no-index --no-setuptools --find-links=$wheelhouse wheel==0.34.2
echo

#Scripts/python get-pip.py --upgrade setuptools
Scripts/python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==46.1.3
echo

pip freeze > $workbench/'_'$venvdir$site'_piplist.txt'
#pip uninstall -y -r $workbench/'_'$venvdir$site'_piplist.txt'
echo

#Scripts/python get-pip.py --upgrade pipdeptree
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pipdeptree==0.13.2
echo

which python
python --version
echo

which pip
pip --version
echo

#python -m pipdeptree --warn silence --local-only --freeze --all > $workbench/'_'$venvdir$site'_package_dep.txt'
#python -m pipdeptree --warn silence --local-only --freeze --all --reverse > $workbench/'_'$venvdir$site'_package_dep_rev.txt'

pip freeze > $workbench/'_'$venvdir$site'_package_freeze.txt'
echo

pip list > $workbench/'_'$venvdir$site'_package_list.txt'
echo

if [ $site = '_ike4' ]; then
	pip list -o > $workbench/$site'_package_update.txt'
	pip list -o
	echo
elif [ $site = '_mums' ]; then
	echo 'skipped pip list -o'
else
	echo 'error site'
fi

cd $workbench/$venvdir/Scripts
deactivate
cd $workbench

echo "completed"

#python setup.py sdist --format=gztar,zip
#python setup.py bdist_wheel

