#!/bin/bash
echo

which python
python --version
echo

which pip
pip --version
echo

site='_ike4'
#site='_mums'

venvdir='ve_jupyter_201906'

req='req_ve_jupyter_201906.txt'

echo '  req: ' $req
echo '  bin: ' $bin
echo '  src: ' $src
echo

workbench='/c/dev/workbench'
wheelhouse='/c/dev/workbench/wheelhouse_201906'

#workbench='/d/workbench'
#wheelhouse='/m/eq.trd/Development/wheelhouse_201906'

#log="/d/workbench/log_instpkg_$venvdir$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
#exec > >(tee ${log}) 2>&1

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - START \\n"

cd $workbench/$venvdir

source Scripts/activate
echo 'activated: '$venvdir
echo

which python
python --version
echo

which pip
pip --version
echo

#Scripts/python get-pip.py --upgrade pip --no-cache-dir 
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pip==19.3.1
echo

#Scripts/python get-pip.py --upgrade wheel --no-cache-dir 
Scripts/python get-pip.py --no-index --no-setuptools --find-links=$wheelhouse wheel==0.33.6
echo

#Scripts/python get-pip.py --upgrade setuptools --no-cache-dir 
#Scripts/python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==42.0.0
#Scripts/python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==42.0.1
Scripts/python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==42.0.2
echo

pip freeze > $workbench/'_'$venvdir$site'_piplist.txt'
pip uninstall -y -r $workbench/'_'$venvdir$site'_piplist.txt'
echo

#Scripts/python get-pip.py --upgrade pipdeptree --no-cache-dir 
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pipdeptree==0.13.2
echo

pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse -r $workbench/$req
echo

#jupyter notebook --generate-config
#echo

jupyter serverextension enable --py jupyterlab --sys-prefix
echo

jupyter nbextensions_configurator enable --user
echo

jupyter contrib nbextension install --user
echo

jupyter nbextension enable autosavetime/main
jupyter nbextension enable codefolding/main
jupyter nbextension enable collapsible_headings/main
jupyter nbextension enable equation-numbering/main
jupyter nbextension enable execute_time/ExecuteTime
jupyter nbextension enable toc2/main
echo

#jupyter nbextension enable --py widgetsnbextension --sys-prefix
#echo

jupyter nbextension enable --py bqplot --sys-prefix
#jupyter nbextension disable --py bqplot
echo

python -m pipdeptree --warn silence --local-only --freeze --all > $workbench/'_'$venvdir$site'_package_dep.txt'
python -m pipdeptree --warn silence --local-only --freeze --all --reverse > $workbench/'_'$venvdir$site'_package_dep_rev.txt'

pip freeze > $workbench/'_'$venvdir$site'_package_freeze.txt'
echo

pip list > $workbench/'_'$venvdir$site'_package_list.txt'
echo

pip list -o > $workbench/'_'$venvdir$site'_package_update.txt'
pip list -o
echo

cd $workbench/$venvdir/Scripts
deactivate
echo 'deactivated: '$venvdir
echo
cd $workbench

python --version
which python
echo

echo "completed"
echo

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - END \\n"


