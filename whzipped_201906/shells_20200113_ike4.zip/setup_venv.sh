#!/bin/bash
echo

which python
python --version
echo

which pip
pip --version
echo

site='_ike4'
#site='_mums'

venvdir='ve_test'
#venvdir='ve_ai'
#venvdir='ve_analytics_201906'
#venvdir='ve_jupyter_201906'

workbench='/c/dev/workbench'
wheelhouse='/c/dev/workbench/wheelhouse_201906'

#workbench='/d/workbench'
#wheelhouse='/m/eq.trd/Development/wheelhouse_201906'

cd $workbench
pwd
echo

if [ -e $venvdir ]; then
	rm -rf $venvdir
	python -m venv $venvdir --clear
	#python -m venv $venvdir --update
	echo $venvdir ' exist'
else
	mkdir $venvdir
	python -m venv $venvdir
	echo $venvdir ' not exist'
fi

cp $workbench/get-pip.py $workbench/$venvdir/get-pip.py


if [ $site = '_mums' ]; then
	if [ $venvdir = 've_test' ]; then
		cp $workbench/activate_test $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_test'
	elif [ $venvdir = 've_ai' ]; then
		cp $workbench/activate_ai $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_ai'
	elif [ $venvdir = 've_analytics_201906' ]; then
		cp $workbench/activate_analytics_201906 $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_analytics_201906'
	elif [ $venvdir = 've_jupyter_201906' ]; then
		cp $workbench/activate_jupyter_201906 $workbench/$venvdir/Scripts/activate
		echo $venvdir ' process ve_jupyter_201906'
	else
		echo $venvdir ' process else'
		:
	fi	
else
	echo $site ' copy activate skipped'
fi

cd $venvdir
pwd
echo

source Scripts/activate

which python
python --version
echo

which pip
pip --version
echo

#Scripts/python get-pip.py --upgrade pip
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pip==19.3.1
echo

#Scripts/python get-pip.py --upgrade wheel
Scripts/python get-pip.py --no-index --no-setuptools --find-links=$wheelhouse wheel==0.33.6
echo

#Scripts/python get-pip.py --upgrade setuptools
Scripts/python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==45.0.0
echo

pip freeze > $workbench/'_'$venvdir$site'_piplist.txt'
#pip uninstall -y -r $workbench/'_'$venvdir$site'_piplist.txt'
echo

#Scripts/python get-pip.py --upgrade pipdeptree
Scripts/python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pipdeptree==0.13.2
echo

which python
python --version
echo

which pip
pip --version
echo

python -m pipdeptree --warn silence --local-only --freeze --all > $workbench/'_'$venvdir$site'_package_dep.txt'
python -m pipdeptree --warn silence --local-only --freeze --all --reverse > $workbench/'_'$venvdir$site'_package_dep_rev.txt'

pip freeze > $workbench/'_'$venvdir$site'_package_freeze.txt'
echo

pip list > $workbench/'_'$venvdir$site'_package_list.txt'
echo

pip list -o > $workbench/'_'$venvdir$site'_package_update.txt'
pip list -o
echo

cd $workbench/$venvdir/Scripts
deactivate
cd $workbench

python --version
which python
echo

echo "completed"

#python setup.py sdist --format=gztar,zip
#python setup.py bdist_wheel

