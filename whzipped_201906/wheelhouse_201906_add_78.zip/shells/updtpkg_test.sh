#!/bin/bash
echo

which python
python --version
echo

which pip
pip --version
echo

site='_ike4'
#site='_mums'

echo $PYTHON3_HOME
echo

#venvdir=''
venvdir='ve_test'
#venvdir='ve_analytics_201906'
#venvdir='ve_jupyter_201906'

req=''
add='req_update_add.txt'
bin='req_update_bdist.txt'
src='req_update_sdist.txt'

echo '  req: ' $req
echo '  add: ' $add
echo '  bin: ' $bin
echo '  src: ' $src
echo

workbench='/c/dev/workbench'
wheelhouse='/c/dev/workbench/wheelhouse_201906'
wheel_maker='/c/dev/workbench/wheel_maker'

#workbench='/d/workbench'
#wheelhouse='/m/eq.trd/Development/wheelhouse_201906'
#wheel_maker='/m/eq.trd/Development/wheel_maker'

#log="/c/dev/workbench/log_updtpkg$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
#log="/d/workbench/log_updtpkg$site"_"`date '+%Y%m%d_%H%M%S'`.txt"
#exec > >(tee ${log}) 2>&1

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - START \\n"

cd $workbench/$venvdir
source Scripts/activate
echo 'activated: '$venvdir
echo

which python
python --version
echo

which pip
pip --version
echo

#python get-pip.py --upgrade pip
#python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pip==19.3.1
#echo

#python get-pip.py --upgrade wheel
#python get-pip.py --no-index --no-setuptools --find-links=$wheelhouse wheel==0.33.6
#echo

#python get-pip.py --upgrade setuptools
#python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==41.6.0
#python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==42.0.0
#python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==42.0.1
#python get-pip.py --no-index --no-wheel --find-links=$wheelhouse setuptools==42.0.2
echo

#pip freeze > $workbench/$site'_piplist.txt'
#pip uninstall -y -r $workbench/$site'_piplist.txt'
#echo

#pip uninstall -y tensorboard

#python get-pip.py --upgrade pipdeptree
#python get-pip.py --no-index --no-setuptools --no-wheel --find-links=$wheelhouse pipdeptree==0.13.2
#echo

### python setup.py sdist --format=gztar,zip
### python setup.py bdist_wheel

#pip wheel --wheel-dir $wheelhouse jupyterlab-server==0.3.3 
#pip wheel --wheel-dir $wheelhouse pixiedust_rosie==0.4 
#pip wheel --wheel-dir $wheelhouse rosie==1.1.3 
#pip wheel --wheel-dir $wheelhouse pixiedust_rosie 
#echo

#pip wheel --wheel-dir $wheelhouse -r $workbench/$src 
echo

#pip wheel --wheel-dir $wheelhouse -r $workbench/$bin
echo

#wheel convert --dest-dir $wheel_maker $wheel_maker/dist/blpapi-3.13.1-py3.6-win-amd64.egg
echo

pip --no-cache-dir install --ignore-installed --no-index --upgrade --find-links=$wheelhouse -r $workbench/$add
echo


#pip uninstall -y jupyterlab 
#echo

#pip uninstall -y gast 
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse gast==0.2.2
#echo 'for tensorflow==2.0'

#pip uninstall -y pdblp 
##pip install $wheelhouse/pdblp-0.1.8.tar.gz
##pip install $wheelhouse/pdblp==0.1.8							
##pip wheel -w $wheelhouse pdblp==0.1.8
##pip install --no-index --upgrade -f $wheelhouse pdblp==0.1.8	
#pip --no-cache-dir install --ignore-installed --no-index -f $wheelhouse pdblp==0.1.8
#echo

#jupyter notebook --generate-config

#jupyter contrib nbextension install --user
#echo

#jupyter nbextensions_configurator enable --user
#echo

#jupyter nbextension enable codefolding/main
#echo

#jupyter contrib nbextensions migrate
#echo

### jupyter nbextension enable --py widgetsnbextension --sys-prefix
#echo

#jupyter nbextension enable --py bqplot --sys-prefix
#echo

#jupyter nbextension disable --py bqplot
#echo

#jupyter serverextension enable --py jupyterlab --sys-prefix
#echo

python -m pipdeptree --warn silence --local-only --freeze --all > $workbench/$site'_package_dep.txt'
python -m pipdeptree --warn silence --local-only --freeze --all --reverse > $workbench/$site'_package_dep_rev.txt'

pip freeze > $workbench/$site'_package_freeze.txt'
echo

pip list > $workbench/$site'_package_list.txt'
echo

pip list -o > $workbench/$site'_package_update.txt'
pip list -o
echo

cd $workbench/$venvdir/Scripts
deactivate
echo 'deactivated: '$venvdir
echo
cd $workbench

python --version
which python
echo

echo "completed"
echo

echo -e "** `date '+%Y-%m-%d %H:%M:%S'` - END \\n"


